import React from "react";
import ReactDOM from "react-dom/client";

import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

import "react-toastify/dist/ReactToastify.css";

import { ToastContainer } from "react-toastify";

import { AuthProvider } from "./context/AuthContext";

import AppRoutes from "./routes/AppRoutes";
import "bootstrap-icons/font/bootstrap-icons.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>

    <AuthProvider>

      <AppRoutes />

      <ToastContainer
        position="top-right"
        autoClose={2500}
      />

    </AuthProvider>

  </React.StrictMode>
);