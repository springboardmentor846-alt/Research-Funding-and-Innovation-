import { useEffect, useState } from "react";
import { Bar, Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend } from "chart.js";
import api from "../api/api";
import "./Dashboard.css";

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [trends, setTrends] = useState({});

  useEffect(() => {
    Promise.all([api.get("/dashboard/summary"), api.get("/dashboard/publication-trends")])
      .then(([summaryResponse, trendResponse]) => {
        setSummary(summaryResponse.data);
        setTrends(trendResponse.data);
      })
      .catch(() => {});
  }, []);

  const years = Object.keys(trends).sort();
  const cards = [
    ["Research profile", summary?.research_profiles, "person-vcard"],
    ["Publications", summary?.publications, "journal-text"],
    ["Patents", summary?.patents, "lightbulb"],
    ["Open funding", summary?.funding_opportunities, "cash-stack"],
  ];

  return (
    <section className="dashboard-page">
      <div className="dashboard-hero">
        <div>
          <p className="eyebrow">INTELLIGENCE HUB</p>
          <h1>Your research, in focus.</h1>
          <p>Track your scholarly footprint and identify your next funding opportunity.</p>
        </div>
        <span className="dashboard-status"><i className="bi bi-circle-fill" /> Live insights</span>
      </div>

      <div className="dashboard-stats">
        {cards.map(([label, value, icon]) => (
          <article className="dashboard-stat" key={label}>
            <i className={`bi bi-${icon}`} /><span>{label}</span><strong>{value ?? "—"}</strong>
          </article>
        ))}
      </div>

      <div className="dashboard-charts">
        <article className="dashboard-chart-card">
          <h2>Publication momentum</h2><p>Publications by year</p>
          <div className="dashboard-chart"><Bar data={{ labels: years, datasets: [{ label: "Publications", data: years.map((year) => trends[year]), backgroundColor: "#5b5ce2", borderRadius: 8 }] }} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }} /></div>
        </article>
        <article className="dashboard-chart-card">
          <h2>Research portfolio</h2><p>Your recorded outputs</p>
          <div className="dashboard-chart"><Doughnut data={{ labels: ["Publications", "Patents"], datasets: [{ data: [summary?.publications || 0, summary?.patents || 0], backgroundColor: ["#5b5ce2", "#28b48c"], borderWidth: 0 }] }} options={{ responsive: true, maintainAspectRatio: false }} /></div>
        </article>
      </div>
    </section>
  );
}
